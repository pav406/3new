﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Participant;

namespace labook3_1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Participant.Participant obj = new Participant.Participant();
                Console.WriteLine("Enter the Participant Details");
                Console.WriteLine("Enter  EmpId : ");
                obj.EmpId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter  Employee in Name : ");
                obj.Name = Console.ReadLine();
                Console.WriteLine("Enter FoundationMarks : ");
                obj.FoundationMarks = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter  webBasicMarks : ");
                obj.WebBasicMarks = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter DotNetMarks : ");
                obj.DotNetMarks = Convert.ToInt32(Console.ReadLine());
                obj.CalculateObtainedMarks();
                obj.CalculatePercentage();
                Console.WriteLine("EmpId {0},Name {1},FoundationMarks {2},DotNetMarks {3},WebBaiscMarks {4}",
                    obj.EmpId, obj.Name, obj.FoundationMarks, obj.DotNetMarks, obj.WebBasicMarks);
            }
            catch (InValidFoundationMarksException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}
