﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labbook3_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = "Eagle";
            Bird b = new Bird(a, 200);
            b.fly();
            b.fly(100);
            Console.ReadKey();
        }
    }
}
