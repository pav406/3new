﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labbook3_4
{
    class Program
    {
        static void Main(string[] args)
        {
            supplier suppi = new supplier();
            int option;
            string retry = "no";
            do
            {

                Console.WriteLine("Enter a number to display or add details of the supplier");
                Console.WriteLine("1.Add supplier details" +
                                  "2. display supplier details");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        suppi.AcceptDetails();
                        break;
                    case 2:
                        suppi.DisplayDetails();
                        break;

                    default:
                        Console.WriteLine("wrong input");
                        break;
                       
                }
                retry = Console.ReadLine();
            } while (retry != "no");

            //while (option < 3)

            //{
            //    if (option == 1)
            //    {
            //        suppi.AcceptDetails();
            //        break;
            //    }
            //    else if(option == 2)
            //    {
            //        suppi.DisplayDetails();
            //        break;

            //    }
            //    else
            //    {
            //        Console.WriteLine("Wrong input");
            //    }
            //}
            Console.ReadKey();


        }
    }
}
