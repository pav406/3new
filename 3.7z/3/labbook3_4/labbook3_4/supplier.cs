﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labbook3_4
{
    class supplier
    {
        int supplierid;
        string supplierName;
        string city;
        int phoneNo;
        string email;
        public void AcceptDetails()
        {
            Console.WriteLine("enter supplierid: \n");
            supplierid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter supplierName:\n");
            supplierName = Console.ReadLine();
            Console.WriteLine("enter city:\n");
            city = Console.ReadLine();
            Console.WriteLine("enter phoneNo:\n");
            phoneNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter Email Id:\n");
            email = Console.ReadLine();
        }
        public void DisplayDetails()
        {
            Console.WriteLine("supplier id is "+supplierid);
            Console.WriteLine("supplier Name is"+supplierName);
            Console.WriteLine("city name is"+city);
            Console.WriteLine("Phone number is"+phoneNo);
            Console.WriteLine("email id is "+email);
        }
        
            
    }
}
